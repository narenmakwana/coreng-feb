1.0.3 / 2016-09-14
------------------

- Unicode update to 9.0.0.
- Rewrite update script (use npm instead of Makefile).
- Added integrity tests.


1.0.2 / 2015-06-24
------------------

- License info clarify, #3.


1.0.1 / 2015-05-30
------------------

- Update to Unicode 8.+.
- Also automatically fix possible ReDOS in `Any`, if source used to generate
  patterns like `(Any)+`.


1.0.0 / 2015-03-10
------------------

- Export all in index.js.


0.1.0 / 2015-02-22
------------------

- First release.
