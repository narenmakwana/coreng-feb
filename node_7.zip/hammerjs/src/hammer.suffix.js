})(window, document, 'Hammer');
