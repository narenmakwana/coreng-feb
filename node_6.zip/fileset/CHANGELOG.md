## Changelog

- Releases: https://github.com/mklabs/node-fileset/releases

### 0.2.1

- Sync API

### 0.2.0

- Drop support for 0.8
- PR mklabs/node-fileset#14 reapplied
- [Minor code style changes](bf8afae22a49cf64720177d6036090db2852d744)

### 0.1.8

- PR mklabs/node-fileset#17 - Reverts PR#14

### 0.1.6 / 0.1.7

- PR mklabs/node-fileset#14

### 0.1.x

- Initial commit
