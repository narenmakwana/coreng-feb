# 1.3.0

2016-11-15

- Add css text

# 1.2.6

2015-08-07

- Add css variables

# 1.2.3

2015-08-07

- Fix documentation for less (issue #7)

# 1.2.2

2015-03-20

- Add random function in the js version


# 1.2.0

2014-11-21

- Update the color (update from Google docs)

# 1.1.0

2014-11-20

- Added text color (alpha) for black and white

# 1.0.0

2014-11-14

- Fixed black and white

# 0.0.2

2014-11-11

- Add the header to the files

# 0.0.1

2014-11-10

 - stylus implementation
 - sass implementation
 - less implementation
 - css implementation
 - js implementation
