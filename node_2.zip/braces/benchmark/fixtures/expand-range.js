module.exports = 'a/b/c/{1..5}/d/e';
