module.exports = 'a/b/c/{x,y}/d/e';
