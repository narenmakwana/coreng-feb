1.0.1 / 2015-09-15
------------------

- Fixed closure compiler compatibility (#1).


1.0.0 / 2015-03-04
------------------

- Added `.decode()`, `.parse()`, `.format()`.


0.0.1 / 2015-03-02
------------------

- First release.
