# 0.3.5 / 2014-06-25

  - changed to use setImmediate in async functions
  - refactored

# 0.3.4 / 2013-11-23

  - changed to throw error if error code is not EEXIST

# 0.3.3 / 2013-11-14

  - changed from fs.exists to fs.open/fs.close/fs.mkdir

# 0.3.2 / 2013-09-08

  - changed from chai to expect.js

# 0.3.1 / 2013-06-19

  - changed to fast mkrand

# 0.3.0 / 2013-04-06

  - changed to create random name again if file exists
  - deleted mode parameter

# 0.2.1 / 2013-02-29

  - added support for node.js 0.10

# 0.2.0 / 2013-02-05

  - changed to replace placeholder near end of line

# 0.1.0 / 2013-01-16

  - initial release
