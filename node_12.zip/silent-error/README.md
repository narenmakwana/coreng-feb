# silent-error [![Build Status](https://travis-ci.org/ember-cli/silent-error.svg)](https://travis-ci.org/ember-cli/silent-error)
