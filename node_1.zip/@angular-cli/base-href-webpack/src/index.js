"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
__export(require('./base-href-webpack-plugin'));
//# sourceMappingURL=/Users/hans/Sources/angular-cli/packages/@angular-cli/base-href-webpack/src/index.js.map