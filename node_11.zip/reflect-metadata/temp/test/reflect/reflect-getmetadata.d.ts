export declare function ReflectGetMetadataInvalidTarget(): void;
export declare function ReflectGetMetadataWithoutTargetKeyWhenNotDefined(): void;
export declare function ReflectGetMetadataWithoutTargetKeyWhenDefined(): void;
export declare function ReflectGetMetadataWithoutTargetKeyWhenDefinedOnPrototype(): void;
export declare function ReflectGetMetadataWithTargetKeyWhenNotDefined(): void;
export declare function ReflectGetMetadataWithTargetKeyWhenDefined(): void;
export declare function ReflectGetMetadataWithTargetKeyWhenDefinedOnPrototype(): void;
