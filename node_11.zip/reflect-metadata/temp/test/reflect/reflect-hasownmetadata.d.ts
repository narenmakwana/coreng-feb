export declare function ReflectHasOwnMetadataInvalidTarget(): void;
export declare function ReflectHasOwnMetadataWithoutTargetKeyWhenNotDefined(): void;
export declare function ReflectHasOwnMetadataWithoutTargetKeyWhenDefined(): void;
export declare function ReflectHasOwnMetadataWithoutTargetKeyWhenDefinedOnPrototype(): void;
export declare function ReflectHasOwnMetadataWithTargetKeyWhenNotDefined(): void;
export declare function ReflectHasOwnMetadataWithTargetKeyWhenDefined(): void;
export declare function ReflectHasOwnMetadataWithTargetKeyWhenDefinedOnPrototype(): void;
