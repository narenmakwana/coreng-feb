export declare function ReflectDeleteMetadataInvalidTarget(): void;
export declare function ReflectDeleteMetadataWhenNotDefinedWithoutTargetKey(): void;
export declare function ReflectDeleteMetadataWhenDefinedWithoutTargetKey(): void;
export declare function ReflectDeleteMetadataWhenDefinedOnPrototypeWithoutTargetKey(): void;
export declare function ReflectHasOwnMetadataAfterDeleteMetadata(): void;
