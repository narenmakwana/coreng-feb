# 0.2.0 / 2013-02-21

  - Refactor into function per-module idiomatic style.
  - Improved test coverage.

# 0.1.0 / 2011-12-13

  - Minor project reorganization

# 0.0.3 / 2011-04-16
  - Support for AMD module loaders

# 0.0.2 / 2011-04-16

  - Ported unit tests
  - Removed functionality that depended on Buffers

# 0.0.1 / 2011-04-15

  - Initial release
