"use strict";
var Observable_1 = require('../../Observable');
var combineLatest_1 = require('../../observable/combineLatest');
Observable_1.Observable.combineLatest = combineLatest_1.combineLatest;
//# sourceMappingURL=combineLatest.js.map