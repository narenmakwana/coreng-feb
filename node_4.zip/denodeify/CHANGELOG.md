# Changelog

## v1.2.0

- Add UMD so that `denodeify` can be used in the browser

## v1.1.2

- Performance improvements, no API changes

## v1.1.1

- Add `'use strict';`

## v1.1.0

- First bower release

## v1.0.0

- First version of `denodeify`
