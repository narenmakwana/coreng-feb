import { Cli } from './cli';
export declare let cli: Cli;
