#!/usr/bin/env node
var argv = require('../../index').argv
console.log(JSON.stringify(argv._));
